module.exports = {
  MTH101: [
    { q: 'The determinant of a 2x2 matrix [[a,b],[c,d]] is:', opts: ['ab-cd', 'ad-bc', 'ac-bd', 'a+d'], a: 1, e: 'det = ad - bc', unit: 1, diff: 'Easy', bloom: 'Remember', co: 'CO1' },
    { q: 'A matrix is invertible only when its determinant is:', opts: ['zero', 'negative', 'non-zero', 'unity'], a: 2, e: 'A singular matrix (det=0) has no inverse', unit: 1, diff: 'Easy', bloom: 'Remember', co: 'CO1' },
    { q: 'sin(2A) equals:', opts: ['2 sinA cosA', 'sinA + cosA', '2 cosA', 'sin^2 A - cos^2 A'], a: 0, e: 'Double-angle identity', unit: 2, diff: 'Easy', bloom: 'Remember', co: 'CO2' },
    { q: 'The derivative of x^3 with respect to x is:', opts: ['3x^2', 'x^2', '3x', 'x^4/4'], a: 0, e: 'Power rule: d/dx(x^n) = n x^(n-1)', unit: 4, diff: 'Easy', bloom: 'Apply', co: 'CO4' },
    { q: 'The standard limit of sinx/x as x approaches 0 is:', opts: ['0', '1', '∞', 'undefined'], a: 1, e: 'lim(x->0) sinx/x = 1', unit: 3, diff: 'Medium', bloom: 'Remember', co: 'CO3' },
    { q: 'The integral of 2x dx is:', opts: ['x^2 + C', '2x^2 + C', 'x + C', '2 + C'], a: 0, e: '∫2x dx = x^2 + C', unit: 5, diff: 'Easy', bloom: 'Apply', co: 'CO5' }
  ],
  PHY101: [
    { q: 'The SI unit of force is:', opts: ['Joule', 'Newton', 'Watt', 'Pascal'], a: 1, e: 'Force = mass × acceleration, unit kg·m/s^2 = Newton', unit: 2, diff: 'Easy', bloom: 'Remember', co: 'CO2' },
    { q: 'For a body starting from rest, v = u + at gives velocity after time t as:', opts: ['at', 'u + at', '2at', 'u - at'], a: 0, e: 'u = 0, so v = at', unit: 1, diff: 'Easy', bloom: 'Apply', co: 'CO1' },
    { q: 'Hooke law states that stress is proportional to:', opts: ['temperature', 'strain', 'pressure', 'volume'], a: 1, e: 'Stress ∝ strain within elastic limit', unit: 3, diff: 'Easy', bloom: 'Remember', co: 'CO3' },
    { q: 'The kinetic energy of a body of mass m moving with velocity v is:', opts: ['mv', 'mv^2', 'mv^2/2', 'm^2v'], a: 2, e: 'KE = (1/2)mv^2', unit: 2, diff: 'Easy', bloom: 'Remember', co: 'CO2' },
    { q: 'The time period of a simple pendulum of length L is:', opts: ['2π√(g/L)', '2π√(L/g)', '√(L/g)', '2πL/g'], a: 1, e: 'T = 2π√(L/g)', unit: 5, diff: 'Medium', bloom: 'Apply', co: 'CO5' },
    { q: 'In SHM, acceleration is proportional to:', opts: ['velocity', 'displacement', 'force', 'energy'], a: 1, e: 'a = -ω^2 x, directed towards mean position', unit: 5, diff: 'Medium', bloom: 'Understand', co: 'CO5' }
  ],
  ENG101: [
    { q: 'Which of these is a barrier to communication?', opts: ['Clear message', 'Noise', 'Feedback', 'Common language'], a: 1, e: 'Noise interferes with the message', unit: 1, diff: 'Easy', bloom: 'Remember', co: 'CO1' },
    { q: 'The 7 Cs of communication include:', opts: ['Clear, concise, concrete', 'Calm, careful, casual', 'Cold, correct, complex', 'Creative, casual, clear'], a: 0, e: '7 Cs: clear, concise, concrete, correct, coherent, complete, courteous', unit: 1, diff: 'Medium', bloom: 'Remember', co: 'CO1' },
    { q: 'Which tense is used for actions happening now?', opts: ['Past perfect', 'Present continuous', 'Future perfect', 'Past simple'], a: 1, e: 'Present continuous = happening now', unit: 2, diff: 'Easy', bloom: 'Apply', co: 'CO2' },
    { q: 'A precis is:', opts: ['a long essay', 'a short summary', 'a poem', 'a letter'], a: 1, e: 'Precis condenses a passage to its core meaning', unit: 3, diff: 'Easy', bloom: 'Remember', co: 'CO3' },
    { q: 'The correct article for "____ honest man" is:', opts: ['a', 'an', 'the', 'no article'], a: 1, e: '\'an\' before vowel sound (honest)', unit: 2, diff: 'Medium', bloom: 'Apply', co: 'CO2' },
    { q: 'Which of these is a type of non-verbal communication?', opts: ['Email', 'Body language', 'Report', 'Notice'], a: 1, e: 'Body language communicates without words', unit: 1, diff: 'Easy', bloom: 'Understand', co: 'CO1' }
  ],
  MTH201: [
    { q: 'The order of the differential equation d^2y/dx^2 + 3dy/dx + y = 0 is:', opts: ['1', '2', '3', '0'], a: 1, e: 'Order = highest derivative = 2', unit: 1, diff: 'Easy', bloom: 'Remember', co: 'CO1' },
    { q: 'The Laplace transform of 1 is:', opts: ['1/s^2', '1/s', 's', 'e^(-s)'], a: 1, e: 'L{1} = 1/s', unit: 2, diff: 'Easy', bloom: 'Remember', co: 'CO2' },
    { q: 'The Laplace transform of e^(at) is:', opts: ['1/(s-a)', '1/(s+a)', 's/(s-a)', 'a/s'], a: 0, e: 'L{e^(at)} = 1/(s-a)', unit: 2, diff: 'Medium', bloom: 'Apply', co: 'CO2' },
    { q: 'The mean of the numbers 2, 4, 6, 8 is:', opts: ['4', '5', '6', '7'], a: 1, e: 'Mean = (2+4+6+8)/4 = 5', unit: 4, diff: 'Easy', bloom: 'Apply', co: 'CO4' },
    { q: 'Newton-Raphson method is used to find:', opts: ['integrals', 'roots of equations', 'derivatives', 'probabilities'], a: 1, e: 'Iterative root-finding method', unit: 5, diff: 'Easy', bloom: 'Understand', co: 'CO5' },
    { q: 'The divergence of a vector field measures:', opts: ['rotation', 'outflow per unit volume', 'temperature', 'pressure'], a: 1, e: 'div F = ∇·F measures flux density', unit: 3, diff: 'Medium', bloom: 'Understand', co: 'CO3' }
  ],
  ELE201: [
    { q: 'According to Ohm law, V = IR means:', opts: ['V ∝ I at constant R', 'I ∝ R at constant V', 'R ∝ V at constant I', 'V ∝ R^2'], a: 0, e: 'Current is proportional to voltage for fixed resistance', unit: 1, diff: 'Easy', bloom: 'Understand', co: 'CO1' },
    { q: 'In a series circuit, the total resistance is:', opts: ['less than the smallest', 'the sum of all resistances', 'the product of resistances', 'half of the sum'], a: 1, e: 'Series: R = R1 + R2 + ...', unit: 1, diff: 'Easy', bloom: 'Apply', co: 'CO1' },
    { q: 'The RMS value of a sinusoidal voltage Vm sin(ωt) is:', opts: ['Vm', 'Vm/√2', 'Vm/2', '2Vm/π'], a: 1, e: 'RMS = peak/√2', unit: 2, diff: 'Medium', bloom: 'Apply', co: 'CO2' },
    { q: 'The unit of inductance is:', opts: ['Farad', 'Henry', 'Ohm', 'Weber'], a: 1, e: 'Inductance is measured in Henry', unit: 2, diff: 'Easy', bloom: 'Remember', co: 'CO2' },
    { q: 'A step-up transformer has:', opts: ['N2 < N1', 'N2 > N1', 'N2 = N1', 'no core'], a: 1, e: 'Secondary turns exceed primary turns', unit: 3, diff: 'Easy', bloom: 'Understand', co: 'CO3' },
    { q: 'The synchronous speed of a 4-pole, 50 Hz induction motor is:', opts: ['1500 rpm', '3000 rpm', '750 rpm', '1000 rpm'], a: 0, e: 'Ns = 120f/P = 120×50/4 = 1500 rpm', unit: 4, diff: 'Medium', bloom: 'Apply', co: 'CO4' }
  ],
  PRC201: [
    { q: 'Which header file is required for printf and scanf?', opts: ['stdlib.h', 'stdio.h', 'string.h', 'math.h'], a: 1, e: 'Standard input/output functions are in stdio.h', unit: 1, diff: 'Easy', bloom: 'Remember', co: 'CO1' },
    { q: 'The default return type of main() in C is:', opts: ['void', 'int', 'char', 'float'], a: 1, e: 'main() returns int by default', unit: 1, diff: 'Medium', bloom: 'Remember', co: 'CO1' },
    { q: 'Which loop executes at least once?', opts: ['while', 'for', 'do-while', 'nested loop'], a: 2, e: 'do-while checks the condition after the body', unit: 2, diff: 'Easy', bloom: 'Understand', co: 'CO2' },
    { q: 'A recursive function is one that:', opts: ['has no return value', 'calls itself', 'uses only global variables', 'returns a pointer'], a: 1, e: 'Recursion = function calling itself', unit: 4, diff: 'Easy', bloom: 'Understand', co: 'CO4' },
    { q: 'strlen("hello") returns:', opts: ['6', '5', '4', '7'], a: 1, e: 'Length of string excluding null character', unit: 3, diff: 'Easy', bloom: 'Apply', co: 'CO3' },
    { q: 'The operator used to access a member through a pointer is:', opts: ['.', '->', '::', '&'], a: 1, e: 'Arrow operator dereferences and accesses', unit: 5, diff: 'Medium', bloom: 'Apply', co: 'CO5' }
  ],
  EDC301: [
    { q: 'A pn junction diode conducts when it is:', opts: ['reverse biased', 'forward biased', 'unbiased', 'broken down always'], a: 1, e: 'Forward bias reduces barrier potential', unit: 1, diff: 'Easy', bloom: 'Understand', co: 'CO1' },
    { q: 'The ripple factor of a full wave rectifier is:', opts: ['1.21', '0.48', '0.8', '2.0'], a: 1, e: 'FWR ripple factor ≈ 0.48', unit: 2, diff: 'Medium', bloom: 'Remember', co: 'CO2' },
    { q: 'In a BJT, the relation between collector, base and emitter currents is:', opts: ['IC = IE + IB', 'IE = IB + IC', 'IB = IE + IC', 'IC = IB - IE'], a: 1, e: 'IE = IB + IC', unit: 3, diff: 'Easy', bloom: 'Remember', co: 'CO3' },
    { q: 'The common emitter current gain β is:', opts: ['IC/IB', 'IB/IC', 'IE/IB', 'IC/IE'], a: 0, e: 'β = IC/IB', unit: 3, diff: 'Easy', bloom: 'Remember', co: 'CO3' },
    { q: 'A zener diode operates in:', opts: ['forward region', 'reverse breakdown region', 'cutoff', 'saturation'], a: 1, e: 'Zener works in reverse breakdown for regulation', unit: 1, diff: 'Medium', bloom: 'Understand', co: 'CO1' },
    { q: 'FET is a device controlled by:', opts: ['input current', 'input voltage', 'temperature', 'light'], a: 1, e: 'FET is voltage-controlled', unit: 5, diff: 'Easy', bloom: 'Understand', co: 'CO5' }
  ],
  CTN302: [
    { q: 'Thevenin theorem replaces a network with:', opts: ['current source and parallel R', 'voltage source and series R', 'a single resistor', 'an inductor'], a: 1, e: 'Vth in series with Rth', unit: 1, diff: 'Easy', bloom: 'Remember', co: 'CO1' },
    { q: 'Maximum power is transferred when load resistance equals:', opts: ['zero', 'Thevenin resistance', 'twice Rth', 'infinity'], a: 1, e: 'RL = Rth for maximum power transfer', unit: 1, diff: 'Medium', bloom: 'Understand', co: 'CO1' },
    { q: 'The time constant of an RC circuit is:', opts: ['R/C', 'RC', '1/RC', 'R+C'], a: 1, e: 'τ = RC seconds', unit: 2, diff: 'Easy', bloom: 'Remember', co: 'CO2' },
    { q: 'Series resonance occurs when:', opts: ['XL = XC', 'XL = 2XC', 'R = XL', 'XL = 0'], a: 0, e: 'At resonance inductive and capacitive reactance are equal', unit: 3, diff: 'Easy', bloom: 'Understand', co: 'CO3' },
    { q: 'The resonant frequency of a series LC circuit is:', opts: ['1/(2π√(LC))', '√(LC)', '2π√(LC)', '1/(2πLC)'], a: 0, e: 'f0 = 1/(2π√(LC))', unit: 3, diff: 'Medium', bloom: 'Apply', co: 'CO3' },
    { q: 'The cutoff frequency of an RC low pass filter is:', opts: ['1/(2πRC)', 'RC', '2πRC', 'R/C'], a: 0, e: 'fc = 1/(2πRC)', unit: 4, diff: 'Medium', bloom: 'Apply', co: 'CO4' }
  ],
  DGE303: [
    { q: 'The decimal equivalent of binary 1010 is:', opts: ['8', '10', '12', '16'], a: 1, e: '1010 = 8+2 = 10', unit: 1, diff: 'Easy', bloom: 'Apply', co: 'CO1' },
    { q: 'Which gate is called the universal gate?', opts: ['AND', 'OR', 'NAND', 'XOR'], a: 2, e: 'NAND and NOR can build any logic function', unit: 2, diff: 'Easy', bloom: 'Remember', co: 'CO2' },
    { q: 'De Morgan theorem states (A+B)\' =', opts: ['A\'B\'', 'A\'+B\'', 'AB', 'A+B'], a: 0, e: 'Complement of OR is AND of complements', unit: 2, diff: 'Medium', bloom: 'Apply', co: 'CO2' },
    { q: 'A multiplexer with 4 inputs requires how many select lines?', opts: ['1', '2', '3', '4'], a: 1, e: '2^n = 4 → n = 2', unit: 3, diff: 'Easy', bloom: 'Apply', co: 'CO3' },
    { q: 'Which flip-flop has no invalid state?', opts: ['SR', 'JK', 'D', 'T'], a: 1, e: 'JK flip-flop avoids the invalid SR state', unit: 4, diff: 'Easy', bloom: 'Understand', co: 'CO4' },
    { q: 'A 4-bit counter counts up to:', opts: ['4', '8', '16', '32'], a: 2, e: '2^4 = 16 states', unit: 4, diff: 'Easy', bloom: 'Apply', co: 'CO4' }
  ],
  ACO401: [
    { q: 'The modulation index of AM is defined as:', opts: ['Vm/Vc', 'Vc/Vm', 'Vm×Vc', 'Vm+Vc'], a: 0, e: 'm = message amplitude / carrier amplitude', unit: 1, diff: 'Medium', bloom: 'Remember', co: 'CO1' },
    { q: 'AM bandwidth for message frequency fm is:', opts: ['fm', '2fm', 'fm/2', '4fm'], a: 1, e: 'Two sidebands → 2fm', unit: 1, diff: 'Easy', bloom: 'Understand', co: 'CO1' },
    { q: 'The superheterodyne receiver uses a fixed:', opts: ['RF frequency', 'IF frequency', 'AF frequency', 'carrier frequency'], a: 1, e: 'Mixing produces constant intermediate frequency', unit: 2, diff: 'Easy', bloom: 'Understand', co: 'CO2' },
    { q: 'In FM, the information is carried by changes in:', opts: ['amplitude', 'frequency', 'phase only', 'polarization'], a: 1, e: 'FM varies carrier frequency with message', unit: 3, diff: 'Easy', bloom: 'Remember', co: 'CO3' },
    { q: 'Carson rule for FM bandwidth is:', opts: ['2fm', '2(Δf + fm)', 'Δf + fm', '2Δf'], a: 1, e: 'BW = 2(Δf + fm)', unit: 3, diff: 'Medium', bloom: 'Apply', co: 'CO3' },
    { q: 'Which modulation gives better noise immunity?', opts: ['AM', 'FM', 'SSB', 'VSB'], a: 1, e: 'FM has superior SNR performance', unit: 4, diff: 'Easy', bloom: 'Understand', co: 'CO4' }
  ],
  MPM402: [
    { q: 'The 8085 microprocessor has how many address lines?', opts: ['8', '16', '32', '4'], a: 1, e: '16 lines → 64 KB memory', unit: 1, diff: 'Easy', bloom: 'Remember', co: 'CO1' },
    { q: 'The accumulator in 8085 is used for:', opts: ['storing program', 'arithmetic and logical operations', 'address generation', 'interrupt control'], a: 1, e: 'A register holds operands and results', unit: 1, diff: 'Easy', bloom: 'Understand', co: 'CO1' },
    { q: 'The instruction CALL in 8085 is used for:', opts: ['jumping permanently', 'calling a subroutine', 'stopping execution', 'incrementing registers'], a: 1, e: 'CALL pushes PC and jumps to subroutine', unit: 2, diff: 'Easy', bloom: 'Understand', co: 'CO2' },
    { q: 'The 8051 has how many I/O ports?', opts: ['2', '3', '4', '8'], a: 2, e: 'Ports P0, P1, P2, P3', unit: 4, diff: 'Easy', bloom: 'Remember', co: 'CO4' },
    { q: 'TRAP in 8085 is a:', opts: ['maskable interrupt', 'non-maskable interrupt', 'software interrupt', 'reset signal'], a: 1, e: 'TRAP cannot be disabled', unit: 3, diff: 'Medium', bloom: 'Remember', co: 'CO3' },
    { q: 'The 8051 internal RAM size is:', opts: ['64 bytes', '128 bytes', '256 bytes', '512 bytes'], a: 1, e: '128 bytes internal data RAM + SFRs', unit: 4, diff: 'Medium', bloom: 'Remember', co: 'CO4' }
  ],
  LIC403: [
    { q: 'An ideal op-amp has:', opts: ['infinite gain and infinite input impedance', 'zero gain', 'finite gain only', 'low input impedance'], a: 0, e: 'Ideal: A=∞, Rin=∞, Rout=0', unit: 1, diff: 'Easy', bloom: 'Remember', co: 'CO1' },
    { q: 'The gain of an inverting amplifier is:', opts: ['1 + Rf/R1', '-Rf/R1', 'R1/Rf', '-R1/Rf'], a: 1, e: 'Av = -Rf/R1', unit: 2, diff: 'Medium', bloom: 'Apply', co: 'CO2' },
    { q: 'The gain of a non-inverting amplifier is:', opts: ['-Rf/R1', '1 + Rf/R1', 'R1/Rf', 'Rf/R1'], a: 1, e: 'Av = 1 + Rf/R1', unit: 2, diff: 'Medium', bloom: 'Apply', co: 'CO2' },
    { q: 'CMRR stands for:', opts: ['Common Mode Rejection Ratio', 'Common Mode Response Range', 'Current Mode Rejection Ratio', 'Control Mode Repetition Rate'], a: 0, e: 'Higher CMRR rejects common-mode noise', unit: 1, diff: 'Easy', bloom: 'Remember', co: 'CO1' },
    { q: 'The 555 timer in astable mode produces:', opts: ['a single pulse', 'a continuous square wave', 'a sine wave', 'a ramp'], a: 1, e: 'Astable = free-running oscillator', unit: 5, diff: 'Easy', bloom: 'Understand', co: 'CO5' },
    { q: 'The time period of 555 monostable output with R and C is:', opts: ['1.1 RC', '0.7 RC', '2.2 RC', 'RC'], a: 0, e: 'T = 1.1 RC', unit: 5, diff: 'Medium', bloom: 'Apply', co: 'CO5' }
  ]
};