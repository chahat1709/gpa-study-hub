module.exports = {
  CNW402: [
    { q: 'The OSI model has how many layers?', opts: ['5', '6', '7', '4'], a: 2, e: 'Physical to Application', unit: 1, diff: 'Easy', bloom: 'Remember', co: 'CO1' },
    { q: 'Which device works at the network layer?', opts: ['switch', 'router', 'hub', 'repeater'], a: 1, e: 'Router routes packets by IP', unit: 3, diff: 'Easy', bloom: 'Understand', co: 'CO3' },
    { q: 'The default subnet mask of Class C IPv4 is:', opts: ['255.0.0.0', '255.255.0.0', '255.255.255.0', '255.255.255.255'], a: 2, e: 'Class C = /24', unit: 3, diff: 'Medium', bloom: 'Remember', co: 'CO3' },
    { q: 'TCP is:', opts: ['connectionless', 'connection-oriented and reliable', 'unreliable', 'only for video'], a: 1, e: 'Handshake + acknowledgements', unit: 4, diff: 'Easy', bloom: 'Understand', co: 'CO4' },
    { q: 'Which protocol resolves domain names to IP?', opts: ['DNS', 'HTTP', 'FTP', 'SMTP'], a: 0, e: 'Domain Name System', unit: 5, diff: 'Easy', bloom: 'Remember', co: 'CO5' },
    { q: 'CSMA/CD is used in:', opts: ['Ethernet', 'Wi-Fi only', 'Bluetooth', 'Fiber only'], a: 0, e: 'Carrier sense with collision detection', unit: 2, diff: 'Medium', bloom: 'Understand', co: 'CO2' }
  ],
  OPS403: [
    { q: 'Which scheduling algorithm is preemptive and time-sliced?', opts: ['FCFS', 'Round Robin', 'SJF', 'Priority non-preemptive'], a: 1, e: 'Quantum-based time sharing', unit: 2, diff: 'Medium', bloom: 'Understand', co: 'CO2' },
    { q: 'FCFS stands for:', opts: ['First Come First Served', 'Fast CPU First Served', 'First Core First System', 'Final Code First Sort'], a: 0, e: 'Processes run in arrival order', unit: 2, diff: 'Easy', bloom: 'Remember', co: 'CO2' },
    { q: 'Deadlock can occur when four conditions hold; which is one of them?', opts: ['mutual exclusion', 'shortest job first', 'round robin', 'preemption'], a: 0, e: 'Mutual exclusion, hold and wait, no preemption, circular wait', unit: 3, diff: 'Medium', bloom: 'Understand', co: 'CO3' },
    { q: 'Virtual memory allows:', opts: ['running programs larger than RAM', 'faster disks', 'more CPUs', 'no paging'], a: 0, e: 'Demand paging + swap', unit: 4, diff: 'Easy', bloom: 'Understand', co: 'CO4' },
    { q: 'LRU page replacement removes:', opts: ['the oldest loaded page', 'least recently used page', 'random page', 'largest page'], a: 1, e: 'Based on usage history', unit: 4, diff: 'Easy', bloom: 'Understand', co: 'CO4' },
    { q: 'The process control block (PCB) contains:', opts: ['process state and registers', 'only program code', 'only data', 'network packets'], a: 0, e: 'Metadata for process management', unit: 2, diff: 'Easy', bloom: 'Understand', co: 'CO2' }
  ],
  WPP501: [
    { q: 'Which HTML tag creates a hyperlink?', opts: ['<a>', '<link>', '<href>', '<url>'], a: 0, e: 'Anchor tag', unit: 1, diff: 'Easy', bloom: 'Remember', co: 'CO1' },
    { q: 'Which CSS property changes text color?', opts: ['font-color', 'color', 'text-color', 'font-style'], a: 1, e: 'color property', unit: 1, diff: 'Easy', bloom: 'Remember', co: 'CO1' },
    { q: 'Which JavaScript keyword declares a block-scoped variable?', opts: ['var', 'let', 'const both', 'define'], a: 2, e: 'let and const are block-scoped', unit: 2, diff: 'Medium', bloom: 'Remember', co: 'CO2' },
    { q: 'PHP files are processed on the:', opts: ['client', 'server', 'router', 'database'], a: 1, e: 'Server-side scripting', unit: 3, diff: 'Easy', bloom: 'Understand', co: 'CO3' },
    { q: 'The method to send form data in the URL is:', opts: ['POST', 'GET', 'COOKIE', 'SESSION'], a: 1, e: 'GET appends data to URL', unit: 3, diff: 'Easy', bloom: 'Understand', co: 'CO3' },
    { q: 'JSON stands for:', opts: ['JavaScript Object Notation', 'Java Script Order Network', 'Joint System Object Name', 'Java Standard Output Node'], a: 0, e: 'Lightweight data format', unit: 4, diff: 'Easy', bloom: 'Remember', co: 'CO4' }
  ],
  SEW502: [
    { q: 'Which model has sequential phases?', opts: ['waterfall', 'scrum', 'kanban', 'prototyping'], a: 0, e: 'Linear: requirements → design → coding → testing', unit: 1, diff: 'Easy', bloom: 'Understand', co: 'CO1' },
    { q: 'Scrum is:', opts: ['a waterfall variant', 'an agile framework', 'a testing tool', 'a programming language'], a: 1, e: 'Iterative sprints with ceremonies', unit: 1, diff: 'Easy', bloom: 'Understand', co: 'CO1' },
    { q: 'SRS stands for:', opts: ['Software Requirement Specification', 'System Resource Storage', 'Source Registry System', 'Software Release Status'], a: 0, e: 'Documents functional and non-functional requirements', unit: 2, diff: 'Easy', bloom: 'Remember', co: 'CO2' },
    { q: 'Which UML diagram shows object interactions over time?', opts: ['sequence diagram', 'class diagram', 'use case diagram', 'component diagram'], a: 0, e: 'Lifelines and messages', unit: 3, diff: 'Easy', bloom: 'Understand', co: 'CO3' },
    { q: 'Boundary value analysis is a:', opts: ['black box technique', 'white box technique', 'database tool', 'UML tool'], a: 0, e: 'Tests at input boundaries', unit: 4, diff: 'Medium', bloom: 'Understand', co: 'CO4' },
    { q: 'COCOMO is used for:', opts: ['effort and cost estimation', 'test automation', 'code review', 'debugging'], a: 0, e: 'Constructive cost model', unit: 5, diff: 'Medium', bloom: 'Understand', co: 'CO5' }
  ],
  CHN503: [
    { q: 'Which is the main circuit board of a PC?', opts: ['motherboard', 'hard disk', 'power supply', 'monitor'], a: 0, e: 'Hosts CPU, RAM and slots', unit: 1, diff: 'Easy', bloom: 'Remember', co: 'CO1' },
    { q: 'RJ45 connector is used with:', opts: ['twisted pair cable', 'coaxial cable', 'power cable', 'HDMI'], a: 0, e: 'Ethernet UTP cable', unit: 3, diff: 'Easy', bloom: 'Remember', co: 'CO3' },
    { q: 'Which device connects multiple networks?', opts: ['hub', 'router', 'switch', 'repeater'], a: 1, e: 'Router forwards between networks', unit: 3, diff: 'Easy', bloom: 'Understand', co: 'CO3' },
    { q: 'The command to test network connectivity is:', opts: ['ping', 'format', 'copy', 'dir'], a: 0, e: 'Sends ICMP echo requests', unit: 5, diff: 'Easy', bloom: 'Apply', co: 'CO5' },
    { q: 'BIOS stands for:', opts: ['Basic Input Output System', 'Binary Input Output System', 'Basic Integrated Operating System', 'Base Input Output Source'], a: 0, e: 'Firmware that boots the PC', unit: 1, diff: 'Easy', bloom: 'Remember', co: 'CO1' },
    { q: 'SSD is faster than HDD because it has:', opts: ['no moving parts', 'more platters', 'larger cache only', 'higher RPM'], a: 0, e: 'Flash memory, no mechanical seek', unit: 1, diff: 'Easy', bloom: 'Understand', co: 'CO1' }
  ],
  PYT601: [
    { q: 'Which symbol denotes a comment in Python?', opts: ['//', '#', '/*', '--'], a: 1, e: 'Hash marks a comment', unit: 1, diff: 'Easy', bloom: 'Remember', co: 'CO1' },
    { q: 'The output of print(2 ** 3) is:', opts: ['6', '8', '9', '23'], a: 1, e: '** is the power operator', unit: 1, diff: 'Easy', bloom: 'Apply', co: 'CO1' },
    { q: 'Which data type is immutable?', opts: ['list', 'tuple', 'dict', 'set'], a: 1, e: 'Tuples cannot be modified', unit: 3, diff: 'Easy', bloom: 'Understand', co: 'CO3' },
    { q: 'The function len("abc") returns:', opts: ['2', '3', '4', '1'], a: 1, e: 'Number of characters', unit: 3, diff: 'Easy', bloom: 'Apply', co: 'CO3' },
    { q: 'Which keyword defines a function in Python?', opts: ['function', 'def', 'func', 'lambda only'], a: 1, e: 'def function_name():', unit: 2, diff: 'Easy', bloom: 'Remember', co: 'CO2' },
    { q: 'try-except is used for:', opts: ['exception handling', 'looping', 'list creation', 'importing'], a: 0, e: 'Catches runtime errors', unit: 4, diff: 'Easy', bloom: 'Understand', co: 'CO4' }
  ],
  CSF602: [
    { q: 'The CIA triad does NOT include:', opts: ['confidentiality', 'integrity', 'availability', 'scalability'], a: 3, e: 'Confidentiality, integrity, availability', unit: 1, diff: 'Easy', bloom: 'Remember', co: 'CO1' },
    { q: 'Which attack sends many requests to overload a server?', opts: ['DoS/DDoS', 'phishing', 'spoofing', 'sniffing'], a: 0, e: 'Denial of service', unit: 1, diff: 'Easy', bloom: 'Understand', co: 'CO1' },
    { q: 'RSA is an example of:', opts: ['symmetric encryption', 'asymmetric encryption', 'hashing', 'steganography'], a: 1, e: 'Public-key cryptography', unit: 2, diff: 'Easy', bloom: 'Remember', co: 'CO2' },
    { q: 'SQL injection is prevented by:', opts: ['parameterized queries', 'longer passwords', 'HTTPS only', 'firewalls only'], a: 0, e: 'Bound parameters separate code from data', unit: 4, diff: 'Medium', bloom: 'Understand', co: 'CO4' },
    { q: 'A firewall filters traffic based on:', opts: ['rules', 'temperature', 'disk space', 'CPU speed'], a: 0, e: 'Packet/application rules', unit: 3, diff: 'Easy', bloom: 'Understand', co: 'CO3' },
    { q: 'MFA stands for:', opts: ['Multi Factor Authentication', 'Multiple File Access', 'Main Firewall Authority', 'Managed Feature Add-on'], a: 0, e: 'Requires two or more factors', unit: 5, diff: 'Easy', bloom: 'Remember', co: 'CO5' }
  ],
  CLB603: [
    { q: 'Which service model provides virtual machines?', opts: ['SaaS', 'IaaS', 'PaaS', 'DaaS'], a: 1, e: 'Infrastructure as a Service', unit: 1, diff: 'Easy', bloom: 'Remember', co: 'CO1' },
    { q: 'Docker is used for:', opts: ['containerization', 'database design', 'networking only', 'UI design'], a: 0, e: 'Packages apps with dependencies', unit: 2, diff: 'Easy', bloom: 'Understand', co: 'CO2' },
    { q: 'AWS is a:', opts: ['cloud provider', 'programming language', 'database', 'framework'], a: 0, e: 'Amazon Web Services', unit: 5, diff: 'Easy', bloom: 'Remember', co: 'CO5' },
    { q: 'A hypervisor runs:', opts: ['virtual machines', 'web pages', 'SQL queries', 'mobile apps'], a: 0, e: 'Manages VMs on hardware', unit: 2, diff: 'Easy', bloom: 'Understand', co: 'CO2' },
    { q: 'Serverless computing means:', opts: ['no servers exist', 'no server management by developer', 'only one server', 'servers on demand only'], a: 1, e: 'Platform manages infrastructure', unit: 3, diff: 'Medium', bloom: 'Understand', co: 'CO3' },
    { q: 'In the shared responsibility model, the customer is responsible for:', opts: ['physical security of data centers', 'their data and access management', 'hypervisor security', 'hardware replacement'], a: 1, e: 'Data, IAM, configurations', unit: 5, diff: 'Medium', bloom: 'Understand', co: 'CO5' }
  ]
};